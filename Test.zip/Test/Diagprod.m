function c=Diagprod(a, B)
c=(a*ones(1,size(B,2))).*B;
end