
global gbl_G2; global gbl_X; global gbl_G; global gbl_Z;
G2 = gbl_G2;
X = gbl_X;
G = gbl_G;
Z = gbl_Z;

X = randn(4, 3);
dX = randn(4, 3)*0.01;

Sf=sum( exp(-i*G*X'), 2);
Sf2=sum( exp(-i*G*(X+dX)'), 2);
dSf = sum(-i*(G*dX').*(exp(-i*G*X')), 2);
disp2(Sf2-Sf)
disp2(dSf)