function out = dHtau(W, dX)
global gbl_Vdual;
global gbl_f;

global gbl_G2; global gbl_X; global gbl_G; global gbl_Z;
G2 = gbl_G2;
X = gbl_X;
G = gbl_G;
Z = gbl_Z;

%Y=W*inv(sqrtm(W'*O(W)));
%n = getn(cI(Y), gbl_f);
%uinv = inv(W'*O(W));
%n = gbl_f*diagouter(cI(W*uinv), cI(W));


dSf = sum(-i*(G*dX').*(exp(-i*G*X')), 2);
dVtilde = (-4*pi*Z./(G2)).*dSf;
dVtilde(1)=0.;
dVdual=cJ(dVtilde);


out = W*0;
for col=1:size(W,2)
out(:,col) = out(:,col) + cIdag(Diagprod(dVdual, cI(W(:,col))));
end
end