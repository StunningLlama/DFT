function Wout = K2(W)
Wout = W;
end