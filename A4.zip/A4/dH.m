function out=dH(W, dW)
global gbl_Vdual;
global gbl_f;
Y=W*inv(sqrtm(W'*O(W)));
n = getn(cI(Y), gbl_f);
uinv = inv(W'*O(W));
dUinv= -uinv*(dW'*O(W) + W'*O(dW))*uinv;
%n2 = gbl_f*diagouter(cI(W*uinv), cI(W));
%disp("test")
%disp2(n)
%disp2(n2)

dn = gbl_f*diagouter(cI(dW*uinv), cI(W))+gbl_f*diagouter(cI(W*dUinv), cI(W))+gbl_f*diagouter(cI(W*uinv), cI(dW));
%disp2(dn)
out = W*0;
for col=1:size(W,2)
out(:,col) = out(:,col) + cIdag(Diagprod(cJdag(O(-4*pi*Linv(O(cJ(dn))))) ...
    + cJdag(O(cJ(excpVWN(n).*dn))) ...
    + Diagprod(excppVWN(n).*dn, cJdag(O(cJ(n)))) ...
    + Diagprod(excpVWN(n), cJdag(O(cJ(dn)))), cI(W(:,col))));
end
end