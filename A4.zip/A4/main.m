test = 2.5

if (test==0) % Test visualization
    X=[8 8 8; 8+1.5 8 8];
    setup(X, 3, 3);
    [W,E1] = iterate();
    visualize(W);
elseif (test == 1) % Test atomic force calculation
    X=[8 8 8; 8+2 8 8];
    setup(X);
    [W,E1] = iterate();
    E1 = E1 + ewald();
    F = getForces(W);
    ds=0.01;
    X=[8 8 8; 8+2+ds 8 8]
    setup(X);
    [W,E2] = iterate();
    E2 = E2 + ewald();
    F
    (E2-E1)/ds
elseif (test == 2) % Direct FD test of dPsiPsi
    X=[8 8 8; 8+2 8 8];
    setup(X, 1, 1);
    %[W,E1] = iterate();
    rng('default');
    rng(245);
    global gbl_active;
    global gbl_Ns;
    W=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dWa=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dWb=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dWa = dWa*0.0000001;
    dWb = dWb*0.0000001;
    
    %dWa = dWa*0.000000;
    %dWb = dWb*0.000000;
    %dWa(3,1)=0.0001;
    %dWb(2,1)=0.0001;
    
    deltaE = (getE(W+dWa+dWb) - getE(W+dWa)) - (getE(W+dWb) - getE(W));
    deltaE
    dwGradE = getPsiPsiDeriv(W, dWb);
    2*real(trace(dWa'*dwGradE))
    %dGrad = getgrad(W+dWa) - getgrad(W);
    %dGrad2 = getPsiPsiDeriv(W, dWa);
    
    %A = H(W+dWa)-H(W);
    %B = dH(W, dWa) + H2(W, dWa);
    %Bp = H(dWa);
elseif (test == 2.5) % Direct FD test of dPsiPsi
    X=[8 8 8; 8+2 8 8];
    setup(X, 1, 1);
    %[W,E1] = iterate();
    rng('default');
    rng(245);
    global gbl_active;
    global gbl_Ns;
    W=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dWa=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dWa = dWa*0.00000000001;
    %dWb = dWb*0.0000001;
    
    %dWa = dWa*0.000000;
    %dWb = dWb*0.000000;
    %dWa(3,1)=0.0001;
    %dWb(2,1)=0.0001;
    
    %dwGradE = getPsiPsiDeriv(W, dWb);
    %2*real(trace(dWa'*dwGradE))
    dGrad = getgrad(W+dWa) - getgrad(W);
    dGrad2 = getPsiPsiDerivWFillings(W, dWa);
    disp2(dGrad);
    disp2(dGrad2);
    %A = H(W+dWa)-H(W);
    %B = dH(W, dWa) + H2(W, dWa);
    %Bp = H(dWa);
elseif (test==3) %FD test dTau
    X=[8 8 8; 8+2 8 8];
    rng('default');
    rng(244);
    W=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dX=(randn(size(X)));
    dX = dX*0.0000001;
    
    setup(X);
    Grad1 = getgrad(W);
    setup(X+dX);
    Grad2 = getgrad(W);
    dGrad = Grad2-Grad1;
    
    setup(X);
    dGradAnal = getPsiTauDeriv(W, dX);
elseif (test==4)
    X=[8 8 8; 8+2 8 8];
    setup(X, 1, 1);
    %[W,E1] = iterate();
    rng('default');
    rng(249);
    global gbl_active;
    global gbl_Ns;
    W=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dW=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dW = dW*0.01;
    dWa = dW*0;
    dWb = dW*0;
    
    indexA = 380;
    indexB = 1020;
    dWa(indexA) = 1;
    dWb(indexB) = 1;
    
    dGrad1 = getPsiPsiDeriv(W, dW);
    dGrad1 = getPsiPsiDeriv(W, dWa);
    c1 = dGrad1(indexB);
    dGrad2 = getPsiPsiDeriv(W, dWb);
    c2 = dGrad2(indexA);
    
    c1
    c2
    disp2(dW'*dGrad1)
    %dGrad = getgrad(W+dWa) - getgrad(W);
    %dGrad2 = getPsiPsiDeriv(W, dWa);
    
    %A = H(W+dWa)-H(W);
    %B = dH(W, dWa) + H2(W, dWa);
    %Bp = H(dWa);
elseif (test==5) %Test that dPsiPsi is symmetric
    
    X=[8 8 8; 8+2 8 8];
    setup(X, 1, 1);
    %[W,E1] = iterate();
    rng('default');
    rng(249);
    global gbl_active;
    global gbl_Ns;
    W=(randn(length(gbl_active),gbl_Ns)+i*randn(length(gbl_active),gbl_Ns));
    dW=(randn(2*length(gbl_active),gbl_Ns));
    %dW = dW*0.01;
    dWa = dW*0;
    dWb = dW*0;
    
    indexA = 3800;
    indexB = 29000;
    dWa(indexA) = 1;
    dWb(indexB) = 1;
    
    %dGrad1 = getdGradtmp(W, dW);
    dGrad1 = getdGradtmp(W, dWa);
    c1 = dGrad1(indexB);
    dGrad2 = getdGradtmp(W, dWb);
    c2 = dGrad2(indexA);
    
    c1
    c2
    %disp2(dW'*dGrad1)
elseif (test==6) % Test conjugate gradient for perturbation
    X=[8 8 8; 8+2 8 8];
    setup(X, 1, 1);
    
    dX=(randn(size(X)));
    
    [W,E1] = iterate();
    disp("Done pt. 1");
    dW = 0.001*pccgWavefunc(W, dX, 100, 1);
    
    
    grad1 = getgrad(W);
    setup(X+dX*0.001, 1, 1);
    grad2 = getgrad(W-dW);
    disp2(grad1);
    disp2(grad2);
end
%visualize(W);